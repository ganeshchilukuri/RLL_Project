package PageFactory;



	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;

	public class HoverMouse 
	{
		private static Actions actions;
		
		@FindBy(xpath = "//span[contains(@class,'anch myacc_2')]")
		private static WebElement myAccount;
		
		
		@FindBy(xpath = "/html/body/div[1]/div[5]/div/div[3]/ul/li[8]/span[2]/ul/li[17]/span")
		private static WebElement logOut;
		
		public HoverMouse(WebDriver driver)
		{
			PageFactory.initElements(driver, this);
			actions = new Actions(driver);
		}
		
		public static void hoverOverMyAccount()
		{
			actions.moveToElement(myAccount).build().perform();
		}
		
		
		
		public static void clickLogOut() {
			logOut.click();
		}
	}


