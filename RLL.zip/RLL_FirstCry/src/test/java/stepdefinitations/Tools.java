package stepdefinitations;



import org.openqa.selenium.WebDriver;

public class Tools {
protected static WebDriver driver;
}


